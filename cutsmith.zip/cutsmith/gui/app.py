"""QApplication setup."""

from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from cutsmith.gui.main_window import MainWindow
from cutsmith.gui.style import APP_QSS


def run() -> int:
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("CutSmith")
    app.setOrganizationName("Anthropic")
    app.setStyleSheet(APP_QSS)
    window = MainWindow()
    window.show()
    window.start_auto_scan()
    return app.exec()
